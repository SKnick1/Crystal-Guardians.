import React, { useState, useEffect } from 'react';
import { Star, Heart, Zap, Shield, Sparkles, Sword, Wand2, Leaf, Flame, Droplets, Wind, Mountain } from 'lucide-react';

interface Character {
  id: string;
  name: string;
  title: string;
  description: string;
  backstory: string;
  element: string;
  icon: React.ReactNode;
  color: string;
  gradient: string;
  stats: {
    health: number;
    energy: number;
    magic: number;
    defense: number;
  };
  abilities: string[];
  level: number;
  experience: number;
}

interface Quest {
  id: string;
  title: string;
  type: 'rescue' | 'treasure' | 'exploration' | 'mystery';
  description: string;
  objective: string;
  difficulty: number;
  duration: string;
  rewards: {
    experience: number;
    crystals: number;
  };
  completed: boolean;
}

interface Monster {
  id: string;
  name: string;
  type: string;
  level: number;
  health: number;
  maxHealth: number;
  element: string;
  icon: string;
  defeated: boolean;
}

function App() {
  const [gameState, setGameState] = useState<'menu' | 'character-select' | 'academy' | 'quest' | 'combat'>('menu');
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const [playerName, setPlayerName] = useState('');
  const [showNameInput, setShowNameInput] = useState(true);
  const [currentQuest, setCurrentQuest] = useState<Quest | null>(null);
  const [currentMonster, setCurrentMonster] = useState<Monster | null>(null);
  const [combatLog, setCombatLog] = useState<string[]>([]);

  const characters: Character[] = [
    {
      id: 'luna',
      name: 'Luna Starweaver',
      title: 'Crystal Mage',
      description: 'Master of starlight magic and crystal healing',
      backstory: 'Luna discovered her powers during a meteor shower and can communicate with crystal spirits.',
      element: 'Star',
      icon: <Sparkles className="w-8 h-8" />,
      color: 'purple',
      gradient: 'from-purple-400 to-pink-500',
      stats: { health: 80, energy: 120, magic: 100, defense: 60 },
      abilities: ['Healing Light', 'Crystal Shield', 'Starfall Strike'],
      level: 1,
      experience: 0
    },
    {
      id: 'finn',
      name: 'Finn Earthshaker',
      title: 'Nature Guardian',
      description: 'Protector of forests and friend to all creatures',
      backstory: 'Raised by forest spirits, Finn can speak to animals and control plant growth.',
      element: 'Earth',
      icon: <Leaf className="w-8 h-8" />,
      color: 'green',
      gradient: 'from-green-400 to-emerald-500',
      stats: { health: 100, energy: 90, magic: 80, defense: 90 },
      abilities: ['Vine Bind', 'Animal Friend', 'Earth Armor'],
      level: 1,
      experience: 0
    },
    {
      id: 'zara',
      name: 'Zara Flameborn',
      title: 'Fire Dancer',
      description: 'Brave warrior with the heart of a dragon',
      backstory: 'Born during a solar eclipse, Zara can create protective fire that never burns friends.',
      element: 'Fire',
      icon: <Flame className="w-8 h-8" />,
      color: 'red',
      gradient: 'from-red-400 to-orange-500',
      stats: { health: 90, energy: 100, magic: 90, defense: 70 },
      abilities: ['Dragon Breath', 'Fire Wall', 'Phoenix Rise'],
      level: 1,
      experience: 0
    },
    {
      id: 'kai',
      name: 'Kai Tidecaller',
      title: 'Ocean Sage',
      description: 'Wise guardian of the seas and master of water magic',
      backstory: 'Found as a baby by mermaids, Kai can breathe underwater and calm any storm.',
      element: 'Water',
      icon: <Droplets className="w-8 h-8" />,
      color: 'blue',
      gradient: 'from-blue-400 to-cyan-500',
      stats: { health: 85, energy: 110, magic: 95, defense: 80 },
      abilities: ['Tidal Wave', 'Healing Rain', 'Ice Shield'],
      level: 1,
      experience: 0
    },
    {
      id: 'aria',
      name: 'Aria Windwhisper',
      title: 'Sky Dancer',
      description: 'Swift messenger who rides the wind currents',
      backstory: 'Blessed by the wind spirits, Aria can fly and predict weather changes.',
      element: 'Air',
      icon: <Wind className="w-8 h-8" />,
      color: 'cyan',
      gradient: 'from-cyan-400 to-sky-500',
      stats: { health: 75, energy: 130, magic: 85, defense: 65 },
      abilities: ['Wind Dash', 'Lightning Bolt', 'Tornado Shield'],
      level: 1,
      experience: 0
    },
    {
      id: 'rocky',
      name: 'Rocky Stonehart',
      title: 'Mountain Guardian',
      description: 'Steadfast protector with unbreakable determination',
      backstory: 'Carved from ancient mountain stone, Rocky awakened to protect the crystal caves.',
      element: 'Stone',
      icon: <Mountain className="w-8 h-8" />,
      color: 'gray',
      gradient: 'from-gray-400 to-stone-500',
      stats: { health: 120, energy: 80, magic: 70, defense: 110 },
      abilities: ['Rock Throw', 'Stone Armor', 'Earthquake'],
      level: 1,
      experience: 0
    }
  ];

  const quests: Quest[] = [
    {
      id: 'crystal-rescue',
      title: 'The Missing Rainbow Crystal',
      type: 'rescue',
      description: 'The Rainbow Crystal has been taken by shadow sprites! Without it, the academy gardens are losing their color.',
      objective: 'Find and rescue the Rainbow Crystal from the Whispering Woods',
      difficulty: 1,
      duration: '15-20 minutes',
      rewards: { experience: 100, crystals: 50 },
      completed: false
    },
    {
      id: 'treasure-cave',
      title: 'Secrets of the Crystal Cave',
      type: 'treasure',
      description: 'Ancient maps reveal a hidden cave filled with power crystals. But mysterious guardians protect its treasures.',
      objective: 'Explore the Crystal Cave and collect 3 Power Gems',
      difficulty: 2,
      duration: '20-25 minutes',
      rewards: { experience: 150, crystals: 75 },
      completed: false
    },
    {
      id: 'lost-village',
      title: 'The Vanishing Village',
      type: 'exploration',
      description: 'An entire village has disappeared into a magical mist! The villagers need a hero to guide them home.',
      objective: 'Navigate the Misty Maze and lead the villagers to safety',
      difficulty: 2,
      duration: '25-30 minutes',
      rewards: { experience: 200, crystals: 100 },
      completed: false
    },
    {
      id: 'crystal-mystery',
      title: 'The Singing Crystal Mystery',
      type: 'mystery',
      description: 'The Great Crystal has started singing strange melodies. Solve the musical puzzle before its magic goes wild!',
      objective: 'Decode the crystal\'s song and restore its harmony',
      difficulty: 3,
      duration: '20-30 minutes',
      rewards: { experience: 250, crystals: 125 },
      completed: false
    }
  ];

  const monsters: Monster[] = [
    {
      id: 'shadow-sprite',
      name: 'Mischief Sprite',
      type: 'Shadow',
      level: 1,
      health: 30,
      maxHealth: 30,
      element: 'Dark',
      icon: '👻',
      defeated: false
    },
    {
      id: 'crystal-golem',
      name: 'Confused Golem',
      type: 'Guardian',
      level: 2,
      health: 50,
      maxHealth: 50,
      element: 'Earth',
      icon: '🗿',
      defeated: false
    },
    {
      id: 'mist-wisp',
      name: 'Lost Wisp',
      type: 'Spirit',
      level: 2,
      health: 40,
      maxHealth: 40,
      element: 'Air',
      icon: '🌫️',
      defeated: false
    }
  ];

  const startGame = () => {
    if (playerName.trim()) {
      setShowNameInput(false);
      setGameState('character-select');
    }
  };

  const selectCharacter = (character: Character) => {
    setSelectedCharacter(character);
    setGameState('academy');
  };

  const startQuest = (quest: Quest) => {
    setCurrentQuest(quest);
    setGameState('quest');
  };

  const startCombat = (monster: Monster) => {
    setCurrentMonster({ ...monster });
    setCombatLog([]);
    setGameState('combat');
  };

  const performAction = (action: string) => {
    if (!currentMonster || !selectedCharacter) return;

    let damage = 0;
    let message = '';

    switch (action) {
      case 'attack':
        damage = Math.floor(Math.random() * 20) + 10;
        message = `${selectedCharacter.name} attacks for ${damage} damage!`;
        break;
      case 'magic':
        damage = Math.floor(Math.random() * 25) + 15;
        message = `${selectedCharacter.name} casts ${selectedCharacter.abilities[0]} for ${damage} damage!`;
        break;
      case 'defend':
        message = `${selectedCharacter.name} defends and recovers energy!`;
        break;
    }

    const newHealth = Math.max(0, currentMonster.health - damage);
    setCurrentMonster(prev => prev ? { ...prev, health: newHealth } : null);
    setCombatLog(prev => [...prev, message]);

    if (newHealth <= 0) {
      setTimeout(() => {
        setCombatLog(prev => [...prev, `${currentMonster.name} is defeated and becomes friendly! 🌟`]);
        setTimeout(() => {
          setSelectedCharacter(prev => prev ? {
            ...prev,
            experience: prev.experience + 50,
            level: prev.experience + 50 >= prev.level * 100 ? prev.level + 1 : prev.level
          } : null);
          setGameState('academy');
        }, 2000);
      }, 1000);
    } else {
      // Monster's turn
      setTimeout(() => {
        const monsterDamage = Math.floor(Math.random() * 15) + 5;
        setCombatLog(prev => [...prev, `${currentMonster.name} retaliates but ${selectedCharacter?.name} stays strong!`]);
      }, 1500);
    }
  };

  const getQuestTypeIcon = (type: string) => {
    switch (type) {
      case 'rescue': return '🏰';
      case 'treasure': return '💎';
      case 'exploration': return '🗺️';
      case 'mystery': return '🔍';
      default: return '⭐';
    }
  };

  const getDifficultyStars = (difficulty: number) => {
    return '⭐'.repeat(difficulty) + '☆'.repeat(3 - difficulty);
  };

  if (showNameInput) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-400 via-purple-400 to-pink-400 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🏰</div>
          <h1 className="text-3xl font-bold text-purple-600 mb-2">Crystal Guardians Academy</h1>
          <p className="text-gray-600 mb-6">Welcome, young guardian! What shall we call you?</p>
          
          <input
            type="text"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            placeholder="Enter your guardian name"
            className="w-full p-4 text-xl border-2 border-purple-300 rounded-2xl mb-6 text-center font-bold"
            onKeyDown={(e) => e.key === 'Enter' && startGame()}
          />
          
          <button
            onClick={startGame}
            disabled={!playerName.trim()}
            className="bg-gradient-to-r from-purple-500 to-pink-500 text-white py-4 px-8 rounded-2xl font-bold text-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 disabled:opacity-50"
          >
            Enter the Academy! ✨
          </button>
        </div>
      </div>
    );
  }

  if (gameState === 'character-select') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-400 to-pink-400 p-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">Choose Your Guardian</h1>
            <p className="text-white/90 text-lg">Select a character to begin your crystal adventure, {playerName}!</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {characters.map((character) => (
              <div
                key={character.id}
                onClick={() => selectCharacter(character)}
                className="bg-white rounded-3xl shadow-xl p-6 cursor-pointer transform hover:scale-105 transition-all duration-200 hover:shadow-2xl"
              >
                <div className={`bg-gradient-to-r ${character.gradient} rounded-2xl p-4 mb-4 text-white text-center`}>
                  {character.icon}
                  <h3 className="font-bold text-xl mt-2">{character.name}</h3>
                  <p className="text-sm opacity-90">{character.title}</p>
                </div>

                <p className="text-gray-600 text-sm mb-4">{character.description}</p>

                <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                  <div className="bg-red-100 rounded-lg p-2 text-center">
                    <Heart className="w-4 h-4 mx-auto mb-1 text-red-500" />
                    <div className="font-bold text-red-600">{character.stats.health}</div>
                  </div>
                  <div className="bg-blue-100 rounded-lg p-2 text-center">
                    <Zap className="w-4 h-4 mx-auto mb-1 text-blue-500" />
                    <div className="font-bold text-blue-600">{character.stats.energy}</div>
                  </div>
                  <div className="bg-purple-100 rounded-lg p-2 text-center">
                    <Wand2 className="w-4 h-4 mx-auto mb-1 text-purple-500" />
                    <div className="font-bold text-purple-600">{character.stats.magic}</div>
                  </div>
                  <div className="bg-green-100 rounded-lg p-2 text-center">
                    <Shield className="w-4 h-4 mx-auto mb-1 text-green-500" />
                    <div className="font-bold text-green-600">{character.stats.defense}</div>
                  </div>
                </div>

                <div className="text-xs text-gray-500">
                  <strong>Special Abilities:</strong>
                  <div className="mt-1">
                    {character.abilities.map((ability, index) => (
                      <span key={index} className="inline-block bg-gray-100 rounded-full px-2 py-1 mr-1 mb-1">
                        {ability}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (gameState === 'academy') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-400 via-blue-400 to-purple-400 p-4">
        <div className="max-w-4xl mx-auto">
          {/* Character Status */}
          <div className="bg-white rounded-3xl shadow-xl p-6 mb-6">
            <div className="flex items-center gap-4 mb-4">
              <div className={`bg-gradient-to-r ${selectedCharacter?.gradient} rounded-2xl p-3 text-white`}>
                {selectedCharacter?.icon}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-800">{selectedCharacter?.name}</h2>
                <p className="text-gray-600">{selectedCharacter?.title}</p>
                <div className="flex items-center gap-2 mt-1">
                  <Star className="w-4 h-4 text-yellow-500" />
                  <span className="text-sm font-bold">Level {selectedCharacter?.level}</span>
                  <span className="text-xs text-gray-500">({selectedCharacter?.experience} XP)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Quest Board */}
          <div className="bg-white rounded-3xl shadow-xl p-6">
            <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">🏰 Academy Quest Board</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {quests.map((quest) => (
                <div
                  key={quest.id}
                  className="border-2 border-gray-200 rounded-2xl p-4 hover:border-purple-300 transition-colors cursor-pointer"
                  onClick={() => startQuest(quest)}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-2xl">{getQuestTypeIcon(quest.type)}</span>
                    <div>
                      <h4 className="font-bold text-gray-800">{quest.title}</h4>
                      <p className="text-xs text-gray-500 capitalize">{quest.type} Quest</p>
                    </div>
                  </div>

                  <p className="text-sm text-gray-600 mb-3">{quest.description}</p>

                  <div className="flex justify-between items-center text-xs">
                    <span className="text-gray-500">{getDifficultyStars(quest.difficulty)}</span>
                    <span className="text-gray-500">{quest.duration}</span>
                  </div>

                  <div className="flex justify-between items-center mt-2 text-xs">
                    <span className="text-blue-600">+{quest.rewards.experience} XP</span>
                    <span className="text-purple-600">+{quest.rewards.crystals} 💎</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (gameState === 'quest') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-400 via-orange-400 to-red-400 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-3xl shadow-xl p-6 mb-6">
            <div className="text-center mb-6">
              <span className="text-4xl">{getQuestTypeIcon(currentQuest?.type || '')}</span>
              <h2 className="text-2xl font-bold text-gray-800 mt-2">{currentQuest?.title}</h2>
              <p className="text-gray-600">{currentQuest?.objective}</p>
            </div>

            <div className="bg-gray-50 rounded-2xl p-4 mb-6">
              <p className="text-gray-700">{currentQuest?.description}</p>
            </div>

            <div className="text-center">
              <p className="text-gray-600 mb-4">You encounter a mysterious creature blocking your path!</p>
              <button
                onClick={() => startCombat(monsters[0])}
                className="bg-gradient-to-r from-red-500 to-orange-500 text-white py-3 px-6 rounded-2xl font-bold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
              >
                Approach Peacefully 🤝
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (gameState === 'combat') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-400 via-pink-400 to-purple-400 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-3xl shadow-xl p-6">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Peaceful Encounter</h2>
              
              <div className="flex justify-between items-center mb-6">
                <div className="text-center">
                  <div className={`bg-gradient-to-r ${selectedCharacter?.gradient} rounded-2xl p-3 text-white mb-2 inline-block`}>
                    {selectedCharacter?.icon}
                  </div>
                  <p className="font-bold">{selectedCharacter?.name}</p>
                </div>
                
                <div className="text-4xl">VS</div>
                
                <div className="text-center">
                  <div className="text-4xl mb-2">{currentMonster?.icon}</div>
                  <p className="font-bold">{currentMonster?.name}</p>
                  <div className="w-24 bg-gray-200 rounded-full h-2 mt-1">
                    <div 
                      className="bg-red-500 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${((currentMonster?.health || 0) / (currentMonster?.maxHealth || 1)) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-2xl p-4 mb-6 h-32 overflow-y-auto">
              {combatLog.map((log, index) => (
                <p key={index} className="text-sm text-gray-700 mb-1">{log}</p>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-3">
              <button
                onClick={() => performAction('attack')}
                className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white py-3 px-4 rounded-2xl font-bold text-sm"
              >
                🤝 Befriend
              </button>
              <button
                onClick={() => performAction('magic')}
                className="bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 px-4 rounded-2xl font-bold text-sm"
              >
                ✨ Use Magic
              </button>
              <button
                onClick={() => performAction('defend')}
                className="bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-4 rounded-2xl font-bold text-sm"
              >
                🛡️ Protect
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
}

export default App;